import { validateEnvironment } from './environment';

const validEnvironment = (): Record<string, string> => ({
  NODE_ENV: 'test',
  PORT: '3000',
  DB_HOST: 'mysql',
  DB_PORT: '3306',
  DB_NAME: 'wrong_question',
  DB_USER: 'wqc_app',
  DB_PASSWORD: 'database-password-with-at-least-32-characters',
  DB_RUN_MIGRATIONS: 'false',
  JWT_ACCESS_SECRET: 'access-secret-with-at-least-32-characters',
  JWT_REFRESH_SECRET: 'refresh-secret-with-at-least-32-characters',
  DATA_ENCRYPTION_KEY: '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',
  HUAWEI_CLIENT_ID: '123456789',
  HUAWEI_CLIENT_SECRET: 'huawei-client-secret',
  HUAWEI_TOKEN_URL: 'https://accounts.example.test/oauth2/v3/token',
  HUAWEI_PROFILE_URL: 'https://accounts.example.test/rest.php?nsp_svc=GOpen.User.getInfo'
});

describe('validateEnvironment', () => {
  it('parses numeric ports and returns a typed configuration', () => {
    const result = validateEnvironment(validEnvironment());

    expect(result.PORT).toBe(3000);
    expect(result.DB_PORT).toBe(3306);
    expect(result.DB_NAME).toBe('wrong_question');
    expect(result.DB_RUN_MIGRATIONS).toBe(false);
  });

  it('rejects a missing required value', () => {
    const environment = validEnvironment();
    delete environment.DB_PASSWORD;

    expect(() => validateEnvironment(environment)).toThrow('DB_PASSWORD is required');
  });

  it('rejects reused access and refresh secrets', () => {
    const environment = validEnvironment();
    environment.JWT_REFRESH_SECRET = environment.JWT_ACCESS_SECRET;

    expect(() => validateEnvironment(environment)).toThrow(
      'JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be different'
    );
  });

  it('requires a 32-byte hexadecimal data encryption key', () => {
    const environment = validEnvironment();
    environment.DATA_ENCRYPTION_KEY = 'short';

    expect(() => validateEnvironment(environment)).toThrow(
      'DATA_ENCRYPTION_KEY must be exactly 64 hexadecimal characters'
    );
  });

  it('requires HTTPS for Huawei credential endpoints', () => {
    const environment = validEnvironment();
    environment.HUAWEI_TOKEN_URL = 'http://accounts.example.test/token';

    expect(() => validateEnvironment(environment)).toThrow(
      'HUAWEI_TOKEN_URL must be a valid HTTPS URL'
    );
  });
});
