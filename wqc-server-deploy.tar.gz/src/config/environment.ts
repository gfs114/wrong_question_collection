export type NodeEnvironment = 'development' | 'test' | 'production';

export interface EnvironmentConfig {
  NODE_ENV: NodeEnvironment;
  PORT: number;
  DB_HOST: string;
  DB_PORT: number;
  DB_NAME: string;
  DB_USER: string;
  DB_PASSWORD: string;
  DB_RUN_MIGRATIONS: boolean;
  JWT_ACCESS_SECRET: string;
  JWT_REFRESH_SECRET: string;
  DATA_ENCRYPTION_KEY: string;
  HUAWEI_CLIENT_ID: string;
  HUAWEI_CLIENT_SECRET: string;
  HUAWEI_TOKEN_URL: string;
  HUAWEI_PROFILE_URL: string;
}

function requiredString(environment: Record<string, unknown>, key: string): string {
  const value = environment[key];
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new Error(`${key} is required`);
  }
  return value.trim();
}

function parsePort(environment: Record<string, unknown>, key: string): number {
  const value = requiredString(environment, key);
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 65535) {
    throw new Error(`${key} must be an integer between 1 and 65535`);
  }
  return parsed;
}

function parseNodeEnvironment(environment: Record<string, unknown>): NodeEnvironment {
  const value = requiredString(environment, 'NODE_ENV');
  if (value !== 'development' && value !== 'test' && value !== 'production') {
    throw new Error('NODE_ENV must be development, test, or production');
  }
  return value;
}

function parseBoolean(environment: Record<string, unknown>, key: string): boolean {
  const value = requiredString(environment, key).toLowerCase();
  if (value === 'true') {
    return true;
  }
  if (value === 'false') {
    return false;
  }
  throw new Error(`${key} must be true or false`);
}

function requireSecret(environment: Record<string, unknown>, key: string): string {
  const value = requiredString(environment, key);
  if (value.length < 32) {
    throw new Error(`${key} must contain at least 32 characters`);
  }
  return value;
}

function requireHttpsUrl(environment: Record<string, unknown>, key: string): string {
  const value = requiredString(environment, key);
  try {
    const url = new URL(value);
    if (url.protocol === 'https:' && url.username === '' && url.password === '') {
      return value;
    }
  } catch {
    // Use one stable configuration error below.
  }
  throw new Error(`${key} must be a valid HTTPS URL`);
}

export function validateEnvironment(environment: Record<string, unknown>): EnvironmentConfig {
  const accessSecret = requireSecret(environment, 'JWT_ACCESS_SECRET');
  const refreshSecret = requireSecret(environment, 'JWT_REFRESH_SECRET');
  if (accessSecret === refreshSecret) {
    throw new Error('JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be different');
  }

  const encryptionKey = requiredString(environment, 'DATA_ENCRYPTION_KEY').toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(encryptionKey)) {
    throw new Error('DATA_ENCRYPTION_KEY must be exactly 64 hexadecimal characters');
  }

  return {
    NODE_ENV: parseNodeEnvironment(environment),
    PORT: parsePort(environment, 'PORT'),
    DB_HOST: requiredString(environment, 'DB_HOST'),
    DB_PORT: parsePort(environment, 'DB_PORT'),
    DB_NAME: requiredString(environment, 'DB_NAME'),
    DB_USER: requiredString(environment, 'DB_USER'),
    DB_PASSWORD: requireSecret(environment, 'DB_PASSWORD'),
    DB_RUN_MIGRATIONS: parseBoolean(environment, 'DB_RUN_MIGRATIONS'),
    JWT_ACCESS_SECRET: accessSecret,
    JWT_REFRESH_SECRET: refreshSecret,
    DATA_ENCRYPTION_KEY: encryptionKey,
    HUAWEI_CLIENT_ID: requiredString(environment, 'HUAWEI_CLIENT_ID'),
    HUAWEI_CLIENT_SECRET: requiredString(environment, 'HUAWEI_CLIENT_SECRET'),
    HUAWEI_TOKEN_URL: requireHttpsUrl(environment, 'HUAWEI_TOKEN_URL'),
    HUAWEI_PROFILE_URL: requireHttpsUrl(environment, 'HUAWEI_PROFILE_URL')
  };
}
