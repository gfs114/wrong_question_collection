import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EnvironmentConfig } from '../config/environment';
import { createDatabaseOptions } from './database-options';
import { ALL_ENTITIES } from './entities';
import { TypeOrmAccountStore } from './typeorm-account.store';
import { TypeOrmDeviceSessionStore } from './typeorm-device-session.store';
import { TypeOrmSyncStore } from './typeorm-sync.store';

function environment(config: ConfigService): EnvironmentConfig {
  return {
    NODE_ENV: config.getOrThrow<EnvironmentConfig['NODE_ENV']>('NODE_ENV'),
    PORT: config.getOrThrow<number>('PORT'),
    DB_HOST: config.getOrThrow<string>('DB_HOST'),
    DB_PORT: config.getOrThrow<number>('DB_PORT'),
    DB_NAME: config.getOrThrow<string>('DB_NAME'),
    DB_USER: config.getOrThrow<string>('DB_USER'),
    DB_PASSWORD: config.getOrThrow<string>('DB_PASSWORD'),
    DB_RUN_MIGRATIONS: config.getOrThrow<boolean>('DB_RUN_MIGRATIONS'),
    JWT_ACCESS_SECRET: config.getOrThrow<string>('JWT_ACCESS_SECRET'),
    JWT_REFRESH_SECRET: config.getOrThrow<string>('JWT_REFRESH_SECRET'),
    DATA_ENCRYPTION_KEY: config.getOrThrow<string>('DATA_ENCRYPTION_KEY'),
    HUAWEI_CLIENT_ID: config.getOrThrow<string>('HUAWEI_CLIENT_ID'),
    HUAWEI_CLIENT_SECRET: config.getOrThrow<string>('HUAWEI_CLIENT_SECRET'),
    HUAWEI_TOKEN_URL: config.getOrThrow<string>('HUAWEI_TOKEN_URL'),
    HUAWEI_PROFILE_URL: config.getOrThrow<string>('HUAWEI_PROFILE_URL')
  };
}

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => createDatabaseOptions(environment(config))
    }),
    TypeOrmModule.forFeature(ALL_ENTITIES)
  ],
  providers: [TypeOrmAccountStore, TypeOrmDeviceSessionStore, TypeOrmSyncStore],
  exports: [TypeOrmModule, TypeOrmAccountStore, TypeOrmDeviceSessionStore, TypeOrmSyncStore]
})
export class DatabaseModule {}
