import { randomUUID } from 'node:crypto';
import {
  Column,
  CreateDateColumn,
  Entity,
  Generated,
  Index,
  PrimaryColumn,
  Unique,
  UpdateDateColumn
} from 'typeorm';

export abstract class BaseEntity {
  @PrimaryColumn({ type: 'char', length: 36 })
  id: string = randomUUID();

  @CreateDateColumn({ type: 'datetime', precision: 3 })
  createdAt!: Date;

  @UpdateDateColumn({ type: 'datetime', precision: 3 })
  updatedAt!: Date;
}

@Entity('users')
export class UserEntity extends BaseEntity {
  @Column({ type: 'varchar', length: 24, default: 'active' })
  status!: string;
}

@Entity('huawei_identities')
@Unique('uq_huawei_identity_union_hash', ['unionIdHash'])
export class HuaweiIdentityEntity extends BaseEntity {
  @Index('idx_huawei_identity_user')
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Column({ type: 'char', length: 64 })
  unionIdHash!: string;

  @Column({ type: 'text' })
  encryptedUnionId!: string;

  @Column({ type: 'text', nullable: true })
  encryptedOpenId!: string | null;
}

@Entity('devices')
@Unique('uq_device_user_key', ['userId', 'deviceKey'])
export class DeviceEntity extends BaseEntity {
  @Index('idx_device_user')
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Column({ type: 'varchar', length: 128 })
  deviceKey!: string;

  @Column({ type: 'varchar', length: 128 })
  name!: string;

  @Column({ type: 'char', length: 36 })
  sessionGeneration!: string;

  @Column({ type: 'datetime', precision: 3 })
  lastSeenAt!: Date;

  @Column({ type: 'datetime', precision: 3, nullable: true })
  revokedAt!: Date | null;
}

@Entity('sessions')
@Unique('uq_session_refresh_hash', ['refreshTokenHash'])
export class SessionEntity extends BaseEntity {
  @Index('idx_session_user')
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Index('idx_session_device')
  @Column({ type: 'char', length: 36 })
  deviceId!: string;

  @Column({ type: 'char', length: 64 })
  refreshTokenHash!: string;

  @Column({ type: 'datetime', precision: 3 })
  expiresAt!: Date;

  @Column({ type: 'datetime', precision: 3, nullable: true })
  revokedAt!: Date | null;
}

@Entity('question_banks')
@Unique('uq_bank_user_client', ['userId', 'clientId'])
export class QuestionBankEntity extends BaseEntity {
  @Index('idx_bank_user')
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Column({ type: 'char', length: 36 })
  clientId!: string;

  @Column({ type: 'varchar', length: 255 })
  name!: string;

  @Column({ type: 'varchar', length: 64 })
  subject!: string;

  @Column({ type: 'int', unsigned: true, default: 1 })
  version!: number;

  @Column({ type: 'datetime', precision: 3, nullable: true })
  deletedAt!: Date | null;
}

@Entity('questions')
@Unique('uq_question_user_client', ['userId', 'clientId'])
export class QuestionEntity extends BaseEntity {
  @Index('idx_question_user')
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Index('idx_question_bank')
  @Column({ type: 'char', length: 36 })
  bankId!: string;

  @Column({ type: 'char', length: 36 })
  clientId!: string;

  @Column({ type: 'varchar', length: 32, default: 'single_choice' })
  type!: string;

  @Column({ type: 'longtext' })
  question!: string;

  @Column({ type: 'json', nullable: true })
  options!: Record<string, string> | null;

  @Column({ type: 'longtext', nullable: true })
  answer!: string | null;

  @Column({ type: 'longtext', nullable: true })
  analysis!: string | null;

  @Column({ type: 'int', unsigned: true, default: 1 })
  version!: number;

  @Column({ type: 'datetime', precision: 3, nullable: true })
  deletedAt!: Date | null;
}

@Entity('wrong_questions')
@Unique('uq_wrong_question_user_client', ['userId', 'questionClientId'])
export class WrongQuestionEntity extends BaseEntity {
  @Index('idx_wrong_question_user')
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Column({ type: 'char', length: 36 })
  questionClientId!: string;

  @Column({ type: 'varchar', length: 24, default: 'pending' })
  status!: string;

  @Column({ type: 'int', unsigned: true, default: 1 })
  version!: number;

  @Column({ type: 'datetime', precision: 3, nullable: true })
  deletedAt!: Date | null;
}

@Entity('review_records')
@Unique('uq_review_user_event', ['userId', 'clientEventId'])
export class ReviewRecordEntity extends BaseEntity {
  @Index('idx_review_user')
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Column({ type: 'char', length: 36 })
  questionClientId!: string;

  @Column({ type: 'char', length: 36 })
  clientEventId!: string;

  @Column({ type: 'varchar', length: 24 })
  result!: string;

  @Column({ type: 'datetime', precision: 3 })
  reviewedAt!: Date;
}

@Entity('sync_operations')
@Unique('uq_sync_operation_user_id', ['userId', 'operationId'])
@Index('idx_sync_operation_user_sequence', ['userId', 'serverSequence'])
export class SyncOperationEntity extends BaseEntity {
  @Column({ type: 'char', length: 36 })
  userId!: string;

  @Column({ type: 'char', length: 36 })
  operationId!: string;

  @Column({ type: 'varchar', length: 32 })
  entityType!: string;

  @Column({ type: 'char', length: 36 })
  entityId!: string;

  @Column({ type: 'varchar', length: 16 })
  operationType!: string;

  @Column({ type: 'bigint', unsigned: true })
  @Generated('increment')
  @Index('uq_sync_operation_sequence', { unique: true })
  serverSequence!: string;

  @Column({ type: 'json' })
  payload!: Record<string, unknown>;
}

export const ALL_ENTITIES = [
  UserEntity,
  HuaweiIdentityEntity,
  DeviceEntity,
  SessionEntity,
  QuestionBankEntity,
  QuestionEntity,
  WrongQuestionEntity,
  ReviewRecordEntity,
  SyncOperationEntity
];
