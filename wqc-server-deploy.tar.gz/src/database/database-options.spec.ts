import { EnvironmentConfig } from '../config/environment';
import { createDatabaseOptions } from './database-options';

describe('createDatabaseOptions', () => {
  it('connects to MySQL without schema synchronization or public assumptions', () => {
    const config: EnvironmentConfig = {
      NODE_ENV: 'production',
      PORT: 3000,
      DB_HOST: 'mysql',
      DB_PORT: 3306,
      DB_NAME: 'wrong_question',
      DB_USER: 'wqc_app',
      DB_PASSWORD: 'database-password-with-at-least-32-characters',
      DB_RUN_MIGRATIONS: false,
      JWT_ACCESS_SECRET: 'access-secret-with-at-least-32-characters',
      JWT_REFRESH_SECRET: 'refresh-secret-with-at-least-32-characters',
      DATA_ENCRYPTION_KEY:
        '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',
      HUAWEI_CLIENT_ID: 'client-id',
      HUAWEI_CLIENT_SECRET: 'client-secret',
      HUAWEI_TOKEN_URL: 'https://accounts.example.test/token',
      HUAWEI_PROFILE_URL: 'https://accounts.example.test/profile'
    };

    const options = createDatabaseOptions(config);

    expect(options).toMatchObject({
      type: 'mysql',
      host: 'mysql',
      port: 3306,
      database: 'wrong_question',
      username: 'wqc_app',
      synchronize: false,
      migrationsRun: false,
      charset: 'utf8mb4'
    });
    expect(options.entities).toHaveLength(9);
  });
});
