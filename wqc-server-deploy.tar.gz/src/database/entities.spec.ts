import { getMetadataArgsStorage } from 'typeorm';
import { ALL_ENTITIES, BaseEntity, DeviceEntity, SyncOperationEntity } from './entities';

describe('database entities', () => {
  it('defines every table required by authentication and synchronization', () => {
    expect(ALL_ENTITIES.map((entity: Function) => getMetadataArgsStorage().tables.find(
      (table) => table.target === entity
    )?.name)).toEqual([
      'users',
      'huawei_identities',
      'devices',
      'sessions',
      'question_banks',
      'questions',
      'wrong_questions',
      'review_records',
      'sync_operations'
    ]);
  });

  it('keeps every synchronized table scoped to a user', () => {
    const userOwnedTables = ALL_ENTITIES.slice(1);

    for (const entity of userOwnedTables) {
      const columns = getMetadataArgsStorage().columns
        .filter((column) => column.target === entity)
        .map((column) => column.propertyName);
      expect(columns).toContain('userId');
    }
  });

  it('makes Huawei identity and client operation identifiers unique per boundary', () => {
    const uniqueDefinitions: string[][] = getMetadataArgsStorage().uniques.map((unique) =>
      Array.isArray(unique.columns) ? unique.columns.map((column) => String(column)) : []
    );

    expect(uniqueDefinitions.some((columns) => columns.includes('unionIdHash'))).toBe(true);
    expect(
      uniqueDefinitions.some(
        (columns) => columns.includes('userId') && columns.includes('operationId')
      )
    ).toBe(true);
  });

  it('assigns a database generated sequence to every accepted sync operation', () => {
    const generation = getMetadataArgsStorage().generations.find(
      (candidate) => candidate.propertyName === 'serverSequence'
    );

    expect(generation?.strategy).toBe('increment');
  });

  it('keeps UUID primary columns aligned with the char(36) migration schema', () => {
    const idColumn = getMetadataArgsStorage().columns.find(
      (column) => column.target === BaseEntity && column.propertyName === 'id'
    );
    expect(idColumn?.options).toMatchObject({ primary: true, type: 'char', length: 36 });
  });

  it('defines the sync cursor index as user and server sequence together', () => {
    const index = getMetadataArgsStorage().indices.find(
      (candidate) =>
        candidate.target === SyncOperationEntity &&
        candidate.name === 'idx_sync_operation_user_sequence'
    );

    expect(index?.columns).toEqual(['userId', 'serverSequence']);
  });

  it('stores a server-generated login generation on each device', () => {
    const column = getMetadataArgsStorage().columns.find(
      (candidate) =>
        candidate.target === DeviceEntity && candidate.propertyName === 'sessionGeneration'
    );

    expect(column?.options).toMatchObject({ type: 'char', length: 36 });
  });
});
